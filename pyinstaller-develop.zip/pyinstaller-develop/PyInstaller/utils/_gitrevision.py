#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "7817d3fac"     # abbreviated commit hash
commit = "7817d3facd341d3af1c1870a1f971170bcf4c6ac"  # commit hash
date = "2018-07-17 09:53:06 -0500"   # commit date
author = "Bryan A. Jones <bjones@ece.msstate.edu>"
ref_names = "HEAD -> develop"  # incl. current branch
commit_message = """Test/CI: Test using newer PyQt5.
"""
